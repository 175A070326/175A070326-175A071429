<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="page_admin.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3" href = "login.php" >Logo <sup>2</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="user.php">
          <span>Quản lý tài khoản</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="login.php">
          <span>Đăng xuất</span></a>
      </li>
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

  <title>User</title>  
  <br /><br />  
  <div class="container">  
   <h3 align="center">Danh sách tài khoản</h3>  
   <br />
   <div align="left">
    <button type="button" name="add" id="add" class="btn btn-success">Thêm tài khoản</button>
   </div>
   <br />
   <table class="table table-bordered table-striped" >
    <thead>
      <tr>
        <th width="5%">ID</th>
        <th>Tên tài khoản</th>
        <th width="10%">Quyền</th>
        <th width="5%">Sửa</th>
        <th width="5%">Xóa</th>
      </tr>
    </thead>
    <tbody id="user_data">
      
    </tbody>
  </table>
  </div>  
  <!-- dang ki -->
<div id="userModal" class="modal fade" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button> 
    </div>
    <div class="modal-body">
    <form id="user_form" method="POST">
     <input type="text" name="tentk" id="tentk" placeholder="Tên tài khoản"><p></p>
     <input type="password" name="matkhau" id="matkhau" placeholder="Mật khẩu"><p></p>
     <input type="text" name="phanquyen" id="phanquyen" placeholder="Quyền"><p></p>
     <input type="hidden" name="id" id="id" /><p></p>
     <input type="hidden" name="action" id="action" value="insert" />
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />
    </form>
   </div>
  </div>
 </div>
</div>


<!--  Update-->
    <div class="modal fade" id="update_country" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
      <div class="modal-header" style="color:back;padding:6px;">
        <h5 class="modal-title"><i class="fa fa-edit"></i> Update</h5>
       <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form method="POST" id="update_form"> 
      <div class="modal-body">
        <form method="POST" id="update_form"> 
        <!--1-->
             <label>Tên tài khoản</label>
            <input type="text" name="tentk_modal" id="tentk_modal" class="form-control" required>
      
        <!--2-->
            <label>Quyền</label>
            <input type="text" name="phanquyen_modal" id="phanquyen_modal" class="form-control" required>
            <p></p>
            <input type="hidden" name="id_modal" id="id_modal" class="form-control-sm">
            <button type="submit" id="update" class="btn btn-default btn-sm" style="background-color: #e35f14;color:#fff;">Lưu</button>
         </form>
      </div>
    </div>
  </div>
<!-- Modal End-->
<script>
$(document).ready(function(){
 
 
 fetch_data(); 

 function fetch_data()
 {
  var action = "fetch";
  $.ajax({
   url:"process-user.php",
   method:"POST",
   data:{action:action},
   success:function(data)
   {
    $('#user_data').html(data);
   }
  })
 }
// sưa
$(document).on("click", "#update", function() { 
    $.ajax({
      url: "update_user.php",
      type: "POST",
      cache: false,
      data:{
        id: $('#id_modal').val(),
        tentk: $('#tentk_modal').val(),
        phanquyen: $('#phanquyen_modal').val(),
      },
      success: function(dataResult){
        var dataResult = JSON.parse(dataResult);
        if(dataResult.statusCode==200){
          $('#update_country').modal().hide();
          alert('Data updated successfully !');
          location.reload();          
        }
      }
    });
  }); 
 //hien form 
$('#add').click(function(e) {
  
  $('#userModal').modal('show');
  $('#user_form')[0].reset();

});
//them
$("#user_form").submit(function (event) {
                event.preventDefault();
      
            var action = "insert";
            var formData = new FormData($(this)[0]);
            $.ajax({
                url: 'process-user.php',
                type: 'POST',
                data: formData,
                async: true,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) 
                {
                    alert(data);
                    fetch_data();
                    $('#user_form')[0].reset();
                    $('#userModal').modal('hide');
                },
                error: function(){
                alert("error in ajax form submission");
                                    }
        });
        return false;
    });
//chọn
  
$(function () {
    $('#update_country').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget); /*Button that triggered the modal*/
      var id = button.data('id');
      var tentk = button.data('tentk');
      var phanquyen = button.data('phanquyen');
      var modal = $(this);
      modal.find('#tentk_modal').val(tentk);
      modal.find('#phanquyen_modal').val(phanquyen);
      modal.find('#id_modal').val(id);
    });
    });
 
 //xoa user-----thanhcong
 $(document).on('click', '.delete', function(){
  var id = $(this).attr("id");
  var action = "delete";
  if(confirm("Bạn có chắc chắn muốn xóa?"))
  {
   $.ajax({
    url:"process-user.php",
    method:"POST",
    data:{id:id, action:action},
    success:function(data)
    {
     alert(data);
     fetch_data();
    }
   })
  }
  else
  {
   return false;
  }
 });
}); 

</script>