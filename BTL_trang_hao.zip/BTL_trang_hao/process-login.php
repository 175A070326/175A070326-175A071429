<?php 
    if(isset($_POST["login"]) && $_POST["tentk"] !='' && $_POST["matkhau"] !='')
    {
        require  'db.php';
        
        mysqli_set_charset($con,'UTF8');
        
       
        $tentk  = $_POST['tentk'];
        $matkhau  = $_POST['matkhau'];
        
        $matkhau = md5($matkhau);
    
        $sqluser = "SELECT * FROM taikhoan WHERE tentk ='$tentk' AND matkhau = '$matkhau'";
        $result = mysqli_query($con,$sqluser);
  
        
       while ($row= mysqli_fetch_array($result)) {
           if ($row["phanquyen"] ==1 ) {
               header("Location:page_admin.php");
           }
           else if ($row["phanquyen"] ==0) {
                header("Location:page_giangvien.php");
           }
       }
    
    }
     else{
        if ($password == '') {
            echo 'Bạn chưa nhập mật khẩu';
        }
        if ($password == '') {
            echo 'Bạn chưa nhập mật khẩu';
        }
        header("Location: login.php");
      
    }
 ?>
