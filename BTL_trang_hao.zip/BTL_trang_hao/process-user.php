<?php 
	
  	if(isset($_POST["action"]))
	{
			require 'db.php';
			////hiện ra
			 if($_POST["action"] == "fetch")
			 {
					$sql = "SELECT id, tentk, phanquyen FROM taikhoan";
					$result = mysqli_query($con, $sql);
					 $output = '
			        <table class="table table-bordered table-striped">
			        ';
					while($row = mysqli_fetch_array($result))
						  {
						   $output .= '
						    <tr>
						     <td>'.$row["id"].'</td>
						     <td>'.$row["tentk"].'</td>
						    <td>'.$row["phanquyen"].'</td>
						    <td><button button type="button" class="btn btn-warning btn-sm edit" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#update_country"
								data-id="'.$row['id'].'"
								data-tentk="'.$row['tentk'].'"
								data-phanquyen="'.$row['phanquyen'].'"
								"><i class="far fa-edit"></i></button></td>
						     <td><button type="button" name="delete" class="btn btn-danger bt-xs delete" id="'.$row["id"].'"><i class="fas fa-trash-alt" ></i></button></td>
						    </tr>
						   ';
						  }
					$output .= '</table>';
					echo $output;
			 }

			 	///thêm
			  if($_POST["action"] == "insert")
				 {
				 	$tentk = $_POST['tentk'];
				 	
				 	$matkhau = $_POST['matkhau'];
				 	$matkhau = md5($matkhau);
				 	$phanquyen = $_POST['phanquyen'];
					$sql = "INSERT INTO taikhoan (tentk, matkhau, phanquyen) 
					VALUES ( '$tentk','$matkhau','$phanquyen')";    
				      if(mysqli_query($con, $sql))
				      {
				       echo 'Thêm thành công';
				      }
				 }
				 	////xóa
			if($_POST["action"] == "delete")
				 {
					 
				  $sql = "DELETE FROM taikhoan WHERE id = '".$_POST["id"]."'";
				  if(mysqli_query($con, $sql))
				  {
				   echo 'Xóa thành công';
				  }
				 }	 
    }
 ?>