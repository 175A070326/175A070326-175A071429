<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="page_admin.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3" href = "#" >Logo <sup>2</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="sinhvien.php">
          <span>Quản lý sinh viên</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="user.php">
          <span>Quản lý điểm</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="user.php">
          <span>Thiết lập trọng số</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="login.php">
          <span>Đăng xuất</span></a>
      </li>
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

  <title>quản lý sinh viên</title>  
  <br /><br />  
  <div class="container">  
   <h3 align="center">Danh sách sinh viên</h3>  
   <br />
   <div align="left">
    <button type="button" name="add" id="add" class="btn btn-success">Thêm sinh viên</button>
   </div>
   <br />
   <table class="table table-bordered table-striped" >
    <thead>
      <tr>
        <th width="45%">Mã sinh viên</th>
        <th width="45%">Tên sinh viên</th>
        <th width="10%">Lớp</th>
      </tr>
    </thead>
    <tbody id="user_data">
      
    </tbody>
  </table>
  </div>  
  <!-- dang ki -->
<div id="userModal" class="modal fade" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button> 
    </div>
    <div class="modal-body">
    <form id="user_form" method="POST">
     <input type="text" name="masv" id="masv" placeholder="Mã sinh viên"><p></p>
     <input type="text" name="tensv" id="tensv" placeholder="Tên sinh viên"><p></p>
     <input type="text" name="lop" id="lop" placeholder="Lớp"><p></p>
     <input type="hidden" name="action" id="action" value="insert" />
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />
    </form>
   </div>
  </div>
 </div>
</div>

<script>
$(document).ready(function(){
 
 
 fetch_data(); 

 function fetch_data()
 {
  var action = "fetch";
  $.ajax({
   url:"process-sinhvien.php",
   method:"POST",
   data:{action:action},
   success:function(data)
   {
    $('#user_data').html(data);
   }
  })
 }
 //hien form 
$('#add').click(function(e) {
  
  $('#userModal').modal('show');
  $('#user_form')[0].reset();

});
//them
$("#user_form").submit(function (event) {
                event.preventDefault();
      
            var action = "insert";
            var formData = new FormData($(this)[0]);
            $.ajax({
                url: 'process-sinhvien.php',
                type: 'POST',
                data: formData,
                async: true,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) 
                {
                    alert(data);
                    fetch_data();
                    $('#user_form')[0].reset();
                    $('#userModal').modal('hide');
                },
                error: function(){
                alert("error in ajax form submission");
                                    }
        });
        return false;
    });
}); 

</script>