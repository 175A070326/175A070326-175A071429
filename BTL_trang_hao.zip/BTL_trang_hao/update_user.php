<?php
	include 'db.php';
	$id=$_POST['id'];
	$tentk=$_POST['tentk'];
	$phanquyen=$_POST['phanquyen'];
	$sql = "UPDATE `taikhoan` SET `tentk`='$tentk',`phanquyen`='$phanquyen' WHERE id=$id";
	if (mysqli_query($con, $sql)) {
		echo 'Sửa thành công';
	}
?>