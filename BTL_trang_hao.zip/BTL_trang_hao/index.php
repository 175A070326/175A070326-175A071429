<!doctype html>
<html lang="en">

<head>
  <title>Trường Đại Học Thuỷ Lợi</title>
  <link rel="stylesheet" href="./style.css">
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
    integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
</head>

<body>
  <header>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12" id="mt">
          <p></p>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <img src="image/logo .png">
          </div>
          <div class="col-md-4">
            
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
          <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Tin Tức và Thông Báo
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Tin Tức</a>
                <a class="dropdown-item" href="#">Thông Báo</a>
                <a class="dropdown-item" href="#">Tin Video</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Tuyển Sinh
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Đại học chính quy</a>
                <a class="dropdown-item" href="#">Thạc sĩ</a>
                <a class="dropdown-item" href="#">Tiến sĩ</a>
                <a class="dropdown-item" href="#">Văn bằng 2</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Sinh Viên
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Quy chế sinh viên</a>
                <a class="dropdown-item" href="#">Hoạt động sinh viên</a>
                <a class="dropdown-item" href="#">Sinh viên tốt nghiệp</a>
                <a class="dropdown-item" href="#">Tra cứu điểm thi</a>
                <a class="dropdown-item" href="#">Học phí</a>
                <a class="dropdown-item" href="#">Đăng kí học</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Gỉang Viên/ Viên Chức
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Thông tin giáo viên</a>
                <a class="dropdown-item" href="#">Lịch giảng dạy</a>
                <a class="dropdown-item" href="#">Đăng nhập</a>
                <a class="dropdown-item" href="#">Tra cứu điểm thi</a>
                <a class="dropdown-item" href="#">Học phí</a>
              </div>
            </li>
            <li class="nav-item" >
              <a class="nav-link" href="tracuudiem.php"  role="button"  aria-haspopup="true" aria-expanded="false">
                Tra cứu điểm
              </a>
            </li>
            <li class="nav-item" >
              <a class="nav-link" href="login.php"  role="button"  aria-haspopup="true" aria-expanded="false">
                Đăng nhập
              </a>
            </li>
      </div>
      </nav>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  </header>

  <main>
    <div class="container">
      <div id="carouselExampleCaptions" class="carousel slide mt-20" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="4"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="5"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="6" class="active"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="image/slide2.jpg" class="d-block w-100" alt="first slide">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <div class="carousel-item">
            <img src="image/slide3.jpg" class="d-block w-100" alt="Second slide">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>

          <div class="carousel-item">
            <img src="image/slide4.jpg" class="d-block w-100 " alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>

          <div class="carousel-item">
            <img src="image/slide5.jpg" class="d-block w-100 " alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
          <div class="carousel-item">
            <img src="image/slide6.jpg" class="d-block w-100" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
      <div class="container" id="new">
        <h4>TIN TỨC NỔI BẬT</h4>
        <div class="row">
          <div class="col-md-4">
            <figure class="figure">
              <img src="image/image1.jpg" class="figure-img img-fluid rounded"
                alt="A generic square placeholder image with rounded corners in a figure.">
              <figcaption class="figure-caption" id="text"><a href="#">Cựu sinh viên Đại học Thủy lợi thưởng 6 tỷ cho 2
                  đội bóng vô địch Seagames 2019.</a></figcaption>
          </div>
          <div class="col-md-4">
            <figure class="figure">
              <img src="image/image2.jpg" class="figure-img img-fluid rounded"
                alt="A generic square placeholder image with rounded corners in a figure.">
              <figcaption class="figure-caption" id="text"><a href="#">Đại học Thủy lợi giành 8 giải thưởng Đồ án xuất
                  sắc - Giải Loa thành năm 2019.</a></figcaption>
          </div>
          <div class="col-md-4">
            <figure class="figure">
              <img src="image/image3.jpg" class="figure-img img-fluid rounded"
                alt="A generic square placeholder image with rounded corners in a figure.">
              <figcaption class="figure-caption" id="text"><a href="#">Thêm 4 chương trình đào tạo tiến hành khảo sát sơ
                  bộ.</a></figcaption>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <h4>CHỌN TRƯỜNG ĐẠI HỌC THUỶ LỢI ĐỂ XÂY DỰNG TƯƠNG LAI , TẠI SAO ?</h4>
        <div class="row">
          <div class="col-md-4">
            <img src="image/media1.jpg" id="img-logo">
          </div>
          <div class="col-md-8">
            <h5><a href="#">
                1. Trường Đại học Thuỷ lợi là một trong những trường đại học giàu truyền thống bậc nhất Việt Nam
              </a></h5>
            <p>Được thành lập năm 1959, Trường Đại học Thuỷ lợi là một trong số ít các trường đại học công lập ra đời
              sớm nhất tại Việt Nam.
              Trụ sở chính của Trường tại 175 Tây Sơn (Đống Đa, Hà Nội) với khuôn viên rộng và kiến trúc độc đáo luôn
              được đánh giá là một
              trong số ít ngôi trường đẹp nhất ở Hà Nội. Toà nhà hành chính của trường thực sự là một điểm nhất kiến
              trúc của Thủ đô, đã được
              hình tượng hoá trong Logo của Trường.
            </p>
          </div>
        </div>
        <div class="row" id="text-2">
          <div class="col-md-4">
            <img src="image/media2.jpg" id="img-logo">
          </div>
          <div class="col-md-8">
            <h5><a href="#">
                2. Trường Đại học Thuỷ lợi có đội ngũ giảng viên chất lượng cao, giàu tâm huyết
              </a></h5>
            <p>
              Với quan điểm đúng đắn về vai trò quyết định của đội ngũ giảng viên đối với chất lượng đào tạo, Trường Đại
              học Thuỷ lợi đã đặt yêu cầu cao và tạo điều kiện tốt nhất để các giảng viên trẻ được đào tạo nâng cao
              trình độ,
              đồng thời tạo môi trường làm việc hấp dẫn để thu hút giảng viên giỏi trình độ cao. Chiến lược phát triển
              đội
              ngũ giảng viên đạt được kết quả hơn cả mong đợi trong 10 năm qua. Số giảng viên có học vị tiến sĩ hiện đạt
              khoảng 240 người, trong đó có 14 Giáo sư và 66 Phó giáo sư.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <img src="image/media3.jpg" id="img-logo">
          </div>
          <div class="col-md-8">
            <h5><a href="#">
                3. Trường Đại học Thủy lợi cam kết mạnh mẽ về đảm bảo chất lượng đào tạo
              </a></h5>
            <p>
              Nhà trường đã và sẽ tiếp tục thực hiện các chính sách phù hợp, đảm bảo điều kiện sống, làm việc,
              học tập tốt nhất cho cán bộ, giảng viên và sinh viên. Trường Đại học Thuỷ lợi cam kết đảm bảo chất
              lượng đào tạo cao giúp sinh viên có cơ hội việc làm tốt nhất sau khi tốt nghiệp. Nhà trường đã,
              đang và sẽ tiếp tục mở rộng hợp tác với các doanh nghiệp trong đào tạo và tuyển dụng lao động.
            </p>
          </div>
          <div class="row">
            <div class="col-md-4">
              <img src="image/media4.jpg" id="img-logo2">
            </div>
            <div class="col-md-8" id="text-4">
              <h5>
                <a href="#">
                  4. Trường Đại học Thủy lợi có cơ sở vật chất thuộc loại tốt nhất trong các trường đại học tại Việt Nam
                </a>
              </h5>
              <p>
                Cơ sở chính nằm trong trung tâm Hà Nội, tại số 175 Tây Sơn – Đống Đa, có diện tích gần 8 ha,
                với các khu hành chính, giảng đường, phòng thí nghiệm, ký túc xá, tiện ích thể thao được nâng cấp khang
                trang,
                hiện đại. Tất cả các phòng làm việc và giảng đường đều được điều hoà không khí. Ký túc xá hiện đáp ứng
                chỗ
                ở cho khoảng 3000 sinh viên. Hoạt động đào tạo, nghiên cứu khoa học của Trường hiện nay vẫn chủ yếu diễn
                ra tại đây.
              </p>
            </div>
          </div>
  </main>
  <footer>
    <div class="container-fluid" id="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6" id="copy">
            <p><b>&copy;2019 ĐẠI HỌC THUỶ LỢI</b></p>
          </div>

          <div class="col-md-6" id="icon">
            <div class="socials">
              <a href="#" class="fb"><i class="fab fa-facebook-f"></i></a>
              <a href="#" class="tw"><i class="fab fa-twitter"></i></a>
              <a href="#" class="gp"><i class="fab fa-google-plus-g"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid" id="map">
      <div class="container">
        <div class="row" id="new">
          <div class="col-md-4">
            <a href="#">
              <img class="img-responsive" src="image/footer.png" />
            </a>
          </div>
          <div class="col-md-8" id="text-3">
            <div class="row">
              <div class="col-md-6">

                <div class="address">TRƯỜNG ĐẠI HỌC THỦY LỢI<br />
                  Địa chỉ : 175 TÂY SƠN, ĐỐNG ĐA, HÀ NỘI.<br />
                  Điện thoại: (024) 3852 2201 - Fax: (024) 3563 3351<br />
                  Email: <a href="#">phonghcth@tlu.edu.vn</a>
                </div>
              </div>

              <div class="col-md-6">

                <div class="address">TRƯỜNG ĐẠI HỌC THỦY LỢI - CƠ SỞ 2<br />
                  Địa chỉ : Số 2 - Đường Trường Sa - P.17 - Q.Bình Thạnh - Tp.Hồ Chí Minh<br />
                  Điện thoại: (84)028.38&nbsp;400 532 - Fax: (84)028.38 400542<br />
                  Email: <a href="#">cs2@tlu.edu.vn</a>
                </div>
              </div>

              <div class="col-md-6">
                <hr width="110%" color="White" />
                <div class="address">TRƯỜNG ĐẠI HỌC THỦY LỢI - CƠ SỞ 2<br />
                  Phường An Thạnh - TX Thuận An - Tỉnh Bình Dương<br />
                  Điện thoại: (84).650.3748 620<br />
                  Fax:(84).650.3833 489/</div>

              </div>
              <hr>
              <div class="col-md-6">
                <hr width="110%" color="White" />
                <div class="address">VIỆN ĐÀO TẠO VÀ KHOA HỌC ỨNG DỤNG MIỀN TRUNG<br />
                  Địa chỉ: Số 115 Trần Phú, Thành phố&nbsp;Phan Rang, Tỉnh Ninh Thuận<br />
                  Điện thoại: 02593.823 027, 02593.823 028<br />
                  Email: <a href="#"> trungtamdh2@tlu.edu.vn</a>
                </div>
                <hr>
              </div>
              <hr>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </footer>





  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
    crossorigin="anonymous"></script>
</body>

</html>