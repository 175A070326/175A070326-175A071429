<?php 
	if(isset($_POST["action"]))
	{
			require 'db.php';
			////hiện ra
			 if($_POST["action"] == "fetch")
			 {
					$sql = "SELECT * FROM sinhvien";
					$result = mysqli_query($con, $sql);
					 $output = '
			        <table class="table table-bordered table-striped">
			        ';
					while($row = mysqli_fetch_array($result))
						  {
						   $output .= '
						    <tr>
						     <td>'.$row["masv"].'</td>
						     <td>'.$row["tensv"].'</td>
						    <td>'.$row["lop"].'</td>
						    </tr>
						   ';
						  }
					$output .= '</table>';
					echo $output;
			 }
			 if($_POST["action"] == "insert")
				 {
				 	$masv = $_POST['masv'];
				 	
				 	$tensv = $_POST['tensv'];
				 	$lop = $_POST['lop'];
					$sql = "INSERT INTO sinhvien (masv, tensv, lop) 
					VALUES ( '$masv','$tensv','$lop')";    
				      if(mysqli_query($con, $sql))
				      {
				       echo 'Thêm thành công';
				      }
				 }
	}
 ?>